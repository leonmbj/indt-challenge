<?php

namespace App\Http\Controllers;

use Validator;
use Illuminate\Http\Request;
use GuzzleHttp\Client;

class BooksController extends Controller
{

    public function index () {
        
        return view('index');
    }

    public function import (Request $request) {

        $validator = Validator::make($request->all(), [
            'file' => 'required|mimes:txt,csv',
        ]);

        if ($validator->fails()) {
            return redirect('/')
                    ->withErrors($validator);
        }

        $csv = fopen($request->file('file')->getRealPath(), 'r');
        $authors = [];
        $books = [];

        while (($data = fgetcsv($csv, 1000, ",")) !== FALSE) {
            $pname = $this->split_name($data[1]);
            $authors[] = [
                'firstName' => $pname[0],
                'lastName' => $pname[1]
            ];
        }

        $cli = new Client(['base_uri' => 'https://bibliapp.herokuapp.com/api/']);
        // dd(json_encode($authors));
        //$authors = $cli->request('GET', 'authors');
        $cli = new Client(['base_uri' => 'https://bibliapp.herokuapp.com/api/']);
        $saveAuthors = $cli->request('POST', 'authors', [
            'json' => $authors
        ]);

        return response()->json($saveAuthors->getBody()->getContents());
        
    }


    public function split_name($name) {
        $name = trim($name);
        $last_name = (strpos($name, ' ') === false) ? '' : preg_replace('#.*\s([\w-]*)$#', '$1', $name);
        $first_name = trim( preg_replace('#'.$last_name.'#', '', $name ) );
        return array($first_name, $last_name);
    }
}
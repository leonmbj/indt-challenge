<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Laravel</title>

        <!-- Bootstrap -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css">

        <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}" type="text/javascript"></script>

    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="import">
                        @foreach ($errors->all() as $error)
                        <div class="alert alert-danger" role="alert">{{ $error }}</div>
                        @endforeach

                        <div class="panel panel-default">
                            <div class="panel-heading"><strong>Importar arquivo</strong> <small> </small></div>
                            <div class="panel-body">
                                <form id="import" action="/import" method="POST" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="input-group image-preview">
                                        <input id="import-label" placeholder="" type="text" class="form-control image-preview-filename" disabled="disabled">
                                        
                                        <span class="input-group-btn">
                                            <div class="btn btn-default image-preview-input">
                                                <span class="glyphicon glyphicon-folder-open"></span> 
                                                <span class="image-preview-input-title">Browse</span>
                                                <input id="import-file" type="file" accept="text/plain, text/csv" name="file"/>
                                            </div>
                                            <button id="import-submit" type="button" class="btn btn-labeled btn-primary">
                                                <span class="btn-label"><i class="glyphicon glyphicon-upload"></i></span> Upload
                                            </button>
                                        </span>
                                    </div>
                                </form>
                                
                                <br />
                                
                                <!-- Progress Bar
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"> <span class="sr-only">60% Complete</span> </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

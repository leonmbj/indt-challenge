<?php

Route::get('/', 'BooksController@index');
Route::post('/import', 'BooksController@import');